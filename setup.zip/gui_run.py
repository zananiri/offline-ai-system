r"""
gui_run.py — GUI launcher for the offline AI system.

Starts Ollama, the FastAPI backend, and the Gradio UI, and shows each one's
live console output in its own tab, with a status indicator per service.
Closing the window stops all three processes.

Run with:
    .venv\Scripts\Activate.ps1
    python gui_run.py

Or double-click via a .bat wrapper (see gui_start.bat) to avoid opening a
console window alongside the GUI.
"""
import queue
import subprocess
import sys
import threading
import time
import tkinter as tk
import urllib.request
import webbrowser
from pathlib import Path
from tkinter import scrolledtext, ttk

PROJECT_ROOT = Path(__file__).resolve().parent
BACKEND_URL = "http://localhost:8000"
UI_URL = "http://localhost:7860"

STATUS_COLORS = {
    "waiting": "#888888",
    "starting": "#C89B3C",
    "running": "#3E7A5C",
    "error": "#9B3B3B",
}


class ServicePanel:
    """One tab: a log pane + status label for a single service."""

    def __init__(self, notebook, name):
        self.name = name
        self.frame = ttk.Frame(notebook)
        notebook.add(self.frame, text=name)

        self.status_var = tk.StringVar(value="Waiting...")
        status_row = ttk.Frame(self.frame)
        status_row.pack(fill="x", padx=8, pady=(8, 4))
        ttk.Label(status_row, text=f"{name}:", font=("Segoe UI", 10, "bold")).pack(side="left")
        self.status_label = ttk.Label(status_row, textvariable=self.status_var, foreground=STATUS_COLORS["waiting"])
        self.status_label.pack(side="left", padx=(6, 0))

        self.text = scrolledtext.ScrolledText(
            self.frame, wrap="word", height=22, bg="#0F1F33", fg="#E3E7EC",
            insertbackground="#E3E7EC", font=("Consolas", 9),
        )
        self.text.pack(fill="both", expand=True, padx=8, pady=(0, 8))
        self.text.configure(state="disabled")

        self.queue = queue.Queue()
        self.process = None

    def set_status(self, text, kind):
        self.status_var.set(text)
        self.status_label.configure(foreground=STATUS_COLORS.get(kind, "#888888"))

    def append_line(self, line):
        self.text.configure(state="normal")
        self.text.insert("end", line)
        self.text.see("end")
        self.text.configure(state="disabled")


def stream_output(process, out_queue):
    """Runs in a background thread; pushes subprocess output lines onto a queue."""
    try:
        for line in iter(process.stdout.readline, ""):
            if line:
                out_queue.put(line)
            else:
                break
    except Exception as e:
        out_queue.put(f"[reader thread error: {e}]\n")


def is_url_up(url, timeout=1.5):
    try:
        urllib.request.urlopen(url, timeout=timeout)
        return True
    except Exception:
        return False


class App:
    def __init__(self, root):
        self.root = root
        root.title("Ibrahim Zananiri - Starting AI Server")
        root.geometry("880x580")
        root.configure(bg="#0F1F33")

        header = ttk.Frame(root)
        header.pack(fill="x", padx=10, pady=(12, 4))
        ttk.Label(
            header, text="Ibrahim Zananiri - Starting AI Server",
            font=("Segoe UI", 20, "bold"),
        ).pack(side="left")

        self.stop_btn = ttk.Button(header, text="Stop All", command=self.stop_all)
        self.stop_btn.pack(side="right")

        self.open_btn = tk.Button(
            header, text="Open UI in Browser", command=self.open_ui,
            state="disabled", bg="#555555", fg="white",
            font=("Segoe UI", 10, "bold"), relief="flat",
            padx=14, pady=6, cursor="hand2", disabledforeground="#AAAAAA",
        )
        self.open_btn.pack(side="right", padx=(0, 10))

        notebook = ttk.Notebook(root)
        notebook.pack(fill="both", expand=True, padx=10, pady=10)

        self.ollama = ServicePanel(notebook, "Ollama")
        self.backend = ServicePanel(notebook, "Backend (FastAPI)")
        self.ui = ServicePanel(notebook, "UI (Gradio)")
        self.panels = [self.ollama, self.backend, self.ui]

        self.closing = False
        root.protocol("WM_DELETE_WINDOW", self.on_close)

        self.start_all()
        self.root.after(150, self.poll_queues)
        self.root.after(1000, self.poll_ollama_health)

    # -----------------------------------------------------------------
    def start_all(self):
        # Ollama: skip launching a new process if it's already running
        if is_url_up("http://localhost:11434"):
            self.ollama.set_status("Already running", "running")
            self.ollama.append_line("Ollama is already running as a background service — not starting a new copy.\n")
        else:
            self.ollama.set_status("Starting...", "starting")
            self.ollama.process = self._spawn(["ollama", "serve"], self.ollama)

        self.backend.set_status("Starting...", "starting")
        self.backend.process = self._spawn(
            [sys.executable, "-m", "uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8000"],
            self.backend,
        )

        self.ui.set_status("Starting...", "starting")
        self.ui.process = self._spawn([sys.executable, "-m", "app.ui"], self.ui)

    def _spawn(self, cmd, panel):
        try:
            process = subprocess.Popen(
                cmd, cwd=str(PROJECT_ROOT),
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, bufsize=1,
                creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, "CREATE_NO_WINDOW") else 0,
            )
        except FileNotFoundError as e:
            panel.set_status("Error", "error")
            panel.append_line(f"Failed to start: {e}\n")
            return None
        threading.Thread(target=stream_output, args=(process, panel.queue), daemon=True).start()
        return process

    # -----------------------------------------------------------------
    def poll_queues(self):
        for panel in self.panels:
            drained = False
            while True:
                try:
                    line = panel.queue.get_nowait()
                except queue.Empty:
                    break
                panel.append_line(line)
                drained = True

                if panel is self.backend and "Application startup complete" in line:
                    panel.set_status("Running", "running")
                if panel is self.ui and "Running on local URL" in line:
                    panel.set_status("Running", "running")
                    self.open_btn.configure(state="normal", bg="#C89B3C", fg="#0F1F33")

            if drained and panel.process and panel.process.poll() is not None:
                # process exited
                panel.set_status(f"Stopped (exit code {panel.process.returncode})", "error")
                if panel is self.ui:
                    self.open_btn.configure(state="disabled", bg="#555555", fg="white")

        if not self.closing:
            self.root.after(150, self.poll_queues)

    def poll_ollama_health(self):
        if not self.closing and self.ollama.status_var.get() not in ("Running", "Already running"):
            if is_url_up("http://localhost:11434"):
                self.ollama.set_status("Running", "running")
        if not self.closing:
            self.root.after(1000, self.poll_ollama_health)

    # -----------------------------------------------------------------
    def open_ui(self):
        webbrowser.open(UI_URL)

    def stop_all(self):
        for panel in self.panels:
            if panel.process and panel.process.poll() is None:
                panel.append_line("\n--- Stopping ---\n")
                panel.process.terminate()
        # give processes a moment, then force-kill any stragglers
        self.root.after(2000, self._force_kill_remaining)

    def _force_kill_remaining(self):
        for panel in self.panels:
            if panel.process and panel.process.poll() is None:
                panel.process.kill()
                panel.set_status("Stopped", "error")
        self.open_btn.configure(state="disabled", bg="#555555", fg="white")

    def on_close(self):
        self.closing = True
        self.stop_all()
        self.root.after(500, self.root.destroy)


if __name__ == "__main__":
    root = tk.Tk()
    style = ttk.Style(root)
    try:
        style.theme_use("vista")
    except tk.TclError:
        pass
    app = App(root)
    root.mainloop()