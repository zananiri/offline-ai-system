"""
Offline translation via MADLAD-400 (CTranslate2, int8). No network calls.

Apache 2.0 licensed (Google Research) — safe for commercial use. This
replaces NLLB-200, which is CC-BY-NC 4.0 and cannot legally be sold.
"""
from pathlib import Path
import ctranslate2
from transformers import AutoTokenizer

MODEL_DIR = Path(__file__).resolve().parent.parent / "models" / "madlad400-ct2"
HF_TOKENIZER_ID = "google/madlad400-3b-mt"  # tokenizer config only, cached locally after first run

# Edit this to match your 7 target languages.
# MADLAD-400 covers 400+ languages, mostly using plain ISO 639-1 codes.
# Full list: https://github.com/google-research/google-research/blob/master/madlad_400/languages.md
LANGUAGES = {
    "english":   "en",
    "french":    "fr",
    "spanish":   "es",
    "german":    "de",
    "arabic":    "ar",
    "chinese":   "zh",
    "russian":   "ru",
    "hebrew":    "he",
}


class Translator:
    def __init__(self, device: str = "auto", compute_type: str = "int8"):
        self.translator = ctranslate2.Translator(str(MODEL_DIR), device=device, compute_type=compute_type)
        self.tokenizer = AutoTokenizer.from_pretrained(HF_TOKENIZER_ID)

    def translate(self, text: str, source_lang: str, target_lang: str) -> str:
        # MADLAD-400 only needs a target-language tag prepended to the source
        # text (e.g. "<2es> Hello") — it infers the source language itself.
        # source_lang is kept in the signature for API/UI compatibility with
        # the rest of the app, which still lets the user pick a source language.
        tgt_code = LANGUAGES[target_lang.lower()]
        tagged_text = f"<2{tgt_code}> {text}"
        tokens = self.tokenizer.convert_ids_to_tokens(self.tokenizer.encode(tagged_text))

        results = self.translator.translate_batch(
            [tokens],
            beam_size=4,
        )
        out_tokens = results[0].hypotheses[0]
        out_ids = self.tokenizer.convert_tokens_to_ids(out_tokens)
        return self.tokenizer.decode(out_ids, skip_special_tokens=True)

    def translate_chunks(self, chunks: list[str], source_lang: str, target_lang: str) -> list[str]:
        return [self.translate(c, source_lang, target_lang) for c in chunks]


# Lazily instantiated singleton so the model loads once per process
_translator: Translator | None = None

def get_translator() -> Translator:
    global _translator
    if _translator is None:
        _translator = Translator()
    return _translator
