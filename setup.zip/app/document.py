"""
Document conversion + OCR via Docling. Handles PDF, DOCX, PPTX, images, etc.
and returns clean Markdown, chunked for translation, or exports to Word.

Two OCR engines are used, deliberately:
- RapidOCR (default) — better accuracy on real-world scans, built-in table
  detection, handles skewed/photographed documents well. This is what
  every document uses unless told otherwise.
- Tesseract (Hebrew only) — RapidOCR (and EasyOCR) have no Hebrew model at
  all; Tesseract is the only engine here that supports Hebrew script. It is
  ONLY used when a document is explicitly marked as Hebrew, specifically to
  avoid trading away RapidOCR's better accuracy on the other 7 languages.
"""
from pathlib import Path
import pypandoc
from docling.document_converter import DocumentConverter, PdfFormatOption
from docling.datamodel.pipeline_options import (
    PdfPipelineOptions, RapidOcrOptions, TesseractCliOcrOptions,
)
from docling.datamodel.base_models import InputFormat

# --- Default converter: RapidOCR (higher accuracy, no Hebrew support) ---
_default_pipeline_options = PdfPipelineOptions()
_default_pipeline_options.do_ocr = True
_default_pipeline_options.ocr_options = RapidOcrOptions()  # ONNX-based, light on CPU
_default_pipeline_options.do_table_structure = True

_default_converter = DocumentConverter(
    format_options={
        InputFormat.PDF: PdfFormatOption(pipeline_options=_default_pipeline_options),
    }
)

# --- Hebrew converter: Tesseract CLI (the only engine here with Hebrew script support) ---
_hebrew_pipeline_options = PdfPipelineOptions()
_hebrew_pipeline_options.do_ocr = True
_hebrew_pipeline_options.ocr_options = TesseractCliOcrOptions(lang=["heb", "eng"])
_hebrew_pipeline_options.do_table_structure = True

_hebrew_converter = DocumentConverter(
    format_options={
        InputFormat.PDF: PdfFormatOption(pipeline_options=_hebrew_pipeline_options),
    }
)


def convert_to_markdown(file_path: str, hebrew: bool = False) -> str:
    """
    Convert any supported document (PDF/DOCX/PPTX/HTML/image) to Markdown.
    Set hebrew=True to route through Tesseract instead of the default
    RapidOCR engine — only do this for documents actually in Hebrew.
    """
    converter = _hebrew_converter if hebrew else _default_converter
    result = converter.convert(Path(file_path))
    return result.document.export_to_markdown()


def export_docx(markdown_text: str, output_path: str) -> str:
    """
    Convert Markdown text to a .docx file via pandoc.
    Used for: PDF -> Word, and OCR'd image -> Word.
    Returns the output_path for convenience.
    """
    pypandoc.convert_text(
        markdown_text,
        to="docx",
        format="md",
        outputfile=output_path,
    )
    return output_path


def convert_file_to_docx(input_path: str, output_path: str, hebrew: bool = False) -> str:
    """
    Full pipeline: any supported input (PDF, image, PPTX, HTML...) -> Word.
    This is what backs the PDF->Word and Image(OCR)->Word conversion endpoints.
    """
    markdown_text = convert_to_markdown(input_path, hebrew=hebrew)
    return export_docx(markdown_text, output_path)


def chunk_text(markdown_text: str, max_chars: int = 800) -> list[str]:
    """Simple paragraph-aware chunking so translation stays within a comfortable range."""
    paragraphs = [p for p in markdown_text.split("\n\n") if p.strip()]
    chunks, current = [], ""
    for p in paragraphs:
        if len(current) + len(p) > max_chars and current:
            chunks.append(current.strip())
            current = ""
        current += p + "\n\n"
    if current.strip():
        chunks.append(current.strip())
    return chunks
